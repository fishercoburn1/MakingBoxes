/**
 * Name:Matthew Pietrucha
 * Professor: Brent Reeves
 * Project: Group Project Week 1
 * do some maths
 *how to compile/build: mvn compile
 *						mvn test
 *usage/how to run: java -cp target/classes box
 */

import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors

public class box 
{
    public static void main( String[] args )
    {
            System.out.println("Please Work");
            work();
  }

  public static void work()
  {
          try {
      File myObj = new File("tester.svg");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
      try {
        FileWriter myWriter = new FileWriter("tester.svg");
        myWriter.write("<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" width=\"100\" height=\"100%\">");
        myWriter.write("<circle cx=\"50\" cy=\"50\" r=\"30\" fill=\"red\">");
        myWriter.write("</svg>");
        myWriter.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
  }
    
}
