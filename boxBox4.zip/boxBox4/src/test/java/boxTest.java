import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.*;

/**
 * Unit test for svg test
 */

public class boxTest
{
    box aBox;
    
    @Before
    public void initialize() {
		aBox = new box();
    }
    
    @Test
    public void testWork() 
    {
    	try {
	    	aBox.work();
		} catch (Exception e) {
	    	System.out.println("test catch");
		}
    }


}









