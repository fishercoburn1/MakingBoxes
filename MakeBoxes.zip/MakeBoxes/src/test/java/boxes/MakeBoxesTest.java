package boxes;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class MakeBoxesTest
{
    boxes.MakeBoxes tester;
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    @Test
    public void testItPrints()
        {
            try {
                double retreived = tester.main;
                assertEquals(1,1);
            } catch (Exception e) {
                System.out.println("N");
            }
        }
}
