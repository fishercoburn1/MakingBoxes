/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 *  Author    : fwc17a - Fisher Coburn
 *  Class     : CS374
 *  Assignment: Week 02 Check - Calculator Testing
 *
 *  Compile by pathing to the Calculator File, and then running mvn test
 *  After running the tests, you are able to see how many of the 15 were ran correctly
 *  There are 3 tests ran per operator (+, -, *, /, %)
 *
 *
 -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*//**
 * Calculator
 * do some maths
 */
import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors

public class MakeBoxes {
  public static void main(String[] args) {
    try {
      File myObj = new File("tester.svg");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
      try {
        FileWriter myWriter = new FileWriter("tester.svg");
        myWriter.write("Files in Java might be tricky, but it is fun enough!");
        myWriter.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
  }
}
