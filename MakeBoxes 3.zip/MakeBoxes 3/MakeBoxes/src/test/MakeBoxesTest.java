

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class MakeBoxesTest
{
    MakeBoxes tester = new MakeBoxes;
    @Test
    tester.main();
    // MakeBoxes tester;
    // /**
    //  * Rigorous Test :-)
    //  */
    // @Test
    // public void shouldAnswerWithTrue()
    // {
    //     assertTrue( true );
    // }
    // @Test
    // public void testItPrints()
    //     {
    //         try {
    //             tester.main();
    //                   if (myObj.createNewFile()) {
    //     System.out.println("File created: " + myObj.getName());
    //   } else {
    //     System.out.println("File already exists.");
    //   }

    //             assertEquals(1,1);
    //         } catch (Exception e) {
    //             System.out.println("N");
    //         }
    //     }
}
