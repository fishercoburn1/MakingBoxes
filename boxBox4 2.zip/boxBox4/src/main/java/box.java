/**
 * Group 2: Fisher Coburn, Matthew Pietr, Mitchell Melrose
 * Professor: Brent Reeves
 * Project: Group Project Week 7
 *how to compile/build: mvn compile
 *						mvn test
 *usage/how to run: java -cp target/classes box
 */

import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.InputStreamReader; //Used to collect user input from the console
import java.io.BufferedReader;
import java.util.*;

public class box 
{
    public static void main( String[] args )
    {
        System.out.println("Please Work");
        work();
    }
    
    public static void work()
    {
        try {
            File myObj = new File("tester.svg");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
           String[] lines = new String[26];
            lines[0] = "<?xml version='1.0' encoding='us-ascii'?>\n";
            lines[1] = "<svg height=\"81.90mm\" viewBox=\"0.0 0.0 120.10 81.90\" width=\"120.10mm\"\n";
            lines[2] = "xmlns=\"http://www.w3.org/2000/svg\" xmlns:cc=\"http://creativecommons.org/ns#\"\n";
            lines[3] = "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n";
            lines[4] = "xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n";
            lines[5] = "xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n";
            lines[6] = "xmlns:svg=\"http://www.w3.org/2000/svg/\"";
            lines[7] = "xmlns:xlink=/\"http://www.w3.org/1999/xlink/\">\n";
            lines[8] = "<g id=\"line-01\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n";
            lines[9] = "<path d=\"M 1.0 2.0 H 11.0\" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n";
            lines[10] = "</g>\n";
            lines[11] = "<g id=\"corner\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n";
            lines[12] = "<path d=\"M 1.0 3.0 H 9.0 V 5.1 \" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n";
            lines[13] = "</g>\n";
            lines[14] = "<g id=\"line-u\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n";
            lines[15] = " <path d=\"M 1.0 4.0 H 7.0 V 8.0 H 1.0 \" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n";
            lines[16] = "</g>\n";
            lines[17] = "<g id=\"rectangle-almost\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n";
            lines[18] = "<path d=\"M 1.0 5.0 H 6.0 v 2.0 H 1.0 V 5.5 \" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n";
            lines[19] = "</g>\n";
            lines[20] = "<g id=\"dovetail\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n";
            lines[21] = "<path d=\"M 1.0 9.0 h 1.0 v 1.0 h 2.0 v -1 h 2.0 v 1 h 2.0 v -1 h 1 \" stroke=\"rgb(255,0,0)\" stroke-width=\"0.20\" />\n";
            lines[22] = "</g>\n";
            lines[23] = "</svg>";
            lines[24] = "<circle cx=\"50\" cy=\"50\" r=\"30\" fill=\"red\">";
            lines[25] = "</svg>";


          FileWriter myWriter = new FileWriter("tester.svg");
            for (int i = 0; i < 25; i++) {
                myWriter.write(lines[i]);

            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    
}
