/**
 * Name:Matthew Pietrucha
 * Professor: Brent Reeves
 * Project: Group Project Week 1
 * do some maths
 *how to compile/build: mvn compile
 *						mvn test
 *usage/how to run: java -cp target/classes box
 */

import java.io.File;  // Import the File class
import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors

public class box 
{
    public static void main( String[] args )
    {
            System.out.println("Please Work");
            work();
  }

  public static void work()
  {
    try {
      File myObj = new File("tester.svg");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
      try {
        FileWriter myWriter = new FileWriter("tester.svg");
        myWriter.write("<?xml version='1.0' encoding='us-ascii'?>\n" +
        "<svg height=\"81.90mm\" viewBox=\"0.0 0.0 120.10 81.90\" width=\"120.10mm\"\n" + "xmlns=\"http://www.w3.org/2000/svg\" xmlns:cc=\"http://creativecommons.org/ns#\"\n" + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n" + "xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n" + "xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n" + "xmlns:svg=\"http://www.w3.org/2000/svg/\"\n" + "xmlns:xlink=\"http://www.w3.org/1999/xlink/\">\n" +
            
                           "<g id=\"line-01\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n" +
                           "<path d=\"M 1.0 2.0 H 11.0\" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n" +
                           "</g>\n" +
                           "<g id=\"corner\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n" +
                           "<path d=\"M 1.0 3.0 H 9.0 V 5.1 \" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n" +
                           "</g>\n" +
                           "<g id=\"line-u\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n" +
                           " <path d=\"M 1.0 4.0 H 7.0 V 8.0 H 1.0 \" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n" +
                           "</g>\n" +
                           "<g id=\"rectangle-almost\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n" +
                           "<path d=\"M 1.0 5.0 H 6.0 v 2.0 H 1.0 V 5.5 \" stroke=\"rgb(0,0,0)\" stroke-width=\"0.20\" />\n" +
                           "</g>\n" +
                           "<g id=\"dovetail\" style=\"fill:none;stroke-linecap:round;stroke-linejoin:round;\">\n" +
                           "<path d=\"M 1.0 9.0 h 1.0 v 1.0 h 2.0 v -1 h 2.0 v 1 h 2.0 v -1 h 1 \" stroke=\"rgb(255,0,0)\" stroke-width=\"0.20\" />\n" +
                           "</g>\n" +
                           "</svg>");
        myWriter.close();
        System.out.println("Successfully wrote to the file.");
      } catch (IOException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
    }
}
